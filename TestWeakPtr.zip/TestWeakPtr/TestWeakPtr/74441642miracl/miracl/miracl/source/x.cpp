#include <stdio.h>
#include "miracl.h"

int main()
{
	int i,len;
	miracl *mip=mirsys(100,0);
	big x,y;
	char b[200];
	x=mirvar(0);
	y=mirvar(0);

	expb2(100,x);
	incr(x,3,x);

	len=big_to_bytes(200,x,b,FALSE);

	for(i=0;i<len;i++)
		printf("%02x",b[i]);

	printf("\n");

	bytes_to_big(len,b,y);
	mip->IOBASE=16;
	cotnum(y,stdout);

	return 0;
}