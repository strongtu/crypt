/*
 *    MIRACL  C++ Header file ZZn12.h
 *
 *    AUTHOR  : M. Scott
 *
 *    NOTE:   : Must be used in conjunction with big.cpp, zzn.cpp and zzn2.cpp, 
 *
 *    PURPOSE : Definition of class ZZn12  (Arithmetic over n^12)
 *              Implemented as a sextic entension over Fp^2
 *
 *              Works with modulus p=5 mod 8, and for which x^12+2 is irreducible
 *              Uses irreducible polynomial X^6+i (i=sqrt(-2))
 *
 * WARNING: This class has been cobbled together for a specific use with
 * the MIRACL library. It is not complete, and may not work in other 
 * applications
 *
 *
 *    Copyright (c) 2006 Shamus Software Ltd.
 */

#ifndef ZZN12_H
#define ZZN12_H

#include "zzn2.h"

extern void init_zzn12(Big,char *);

class ZZn12
{
    
    ZZn2 a[6];
public:
    ZZn12()   {}
    ZZn12(int w) {a[0]=(ZZn2)w; a[1]=a[2]=a[3]=a[4]=a[5]=0;}
    ZZn12(const ZZn12& w) {a[0]=w.a[0]; a[1]=w.a[1]; a[2]=w.a[2];
                         a[3]=w.a[3]; a[4]=w.a[4]; a[5]=w.a[5];}

    ZZn12(const Big &x)  {a[0]=(ZZn2)x; a[1]=a[2]=a[3]=a[4]=a[5]=0;}
    ZZn12(const ZZn2& x) {a[0]=x; a[1]=a[2]=a[3]=a[4]=a[5]=0;}

    void set(const ZZn2 *x) {a[0]=x[0]; a[1]=x[1];a[2]=x[2]; 
                             a[3]=x[3]; a[4]=x[4];a[5]=x[5];}

    void set(const Big &x) {a[0]=(ZZn2)x; a[1]=a[2]=a[3]=a[4]=a[5]=0;}
    void set(const ZZn2 &x) {a[0]=x; a[1]=a[2]=a[3]=a[4]=a[5]=0;}
    void set(const ZZn2 &x,int i) {a[0]=a[1]=a[2]=a[3]=a[4]=a[5]=0; a[i]=x; }

    void get(ZZn2 *) ;
    void get(ZZn2 &) ;
    
    void clear() {a[0]=a[1]=a[2]=a[3]=a[4]=a[5]=0;}
    
    BOOL iszero()  const {if (a[0].iszero() && a[1].iszero() && a[2].iszero() 
                           && a[3].iszero() && a[4].iszero() && a[5].iszero()) return TRUE; return FALSE; }
    BOOL isunity() const {if (a[0].isunity() && a[1].iszero() && a[2].iszero() 
                           && a[3].iszero() && a[4].iszero() && a[5].iszero()) return TRUE; return FALSE; }
    BOOL isminusone() const {if (a[0].isminusone() && a[1].iszero() && a[2].iszero() 
                           && a[3].iszero() && a[4].iszero() && a[5].iszero()) return TRUE; return FALSE; }

    ZZn12& powq(const ZZn12*);
    ZZn12& operator=(int i) {a[0]=(ZZn2)i; a[1]=a[2]=a[3]=a[4]=a[5]=0; return *this;}
    ZZn12& operator=(const ZZn2& x)  {a[0]=x; a[1]=a[2]=a[3]=a[4]=a[5]=0; return *this; }
    ZZn12& operator=(const ZZn12& x) {a[0]=x.a[0]; a[1]=x.a[1]; a[2]=x.a[2];  
                                    a[3]=x.a[3]; a[4]=x.a[4]; a[5]=x.a[5]; return *this; }
    ZZn12& operator+=(const ZZn2& x) {a[0]+=x; return *this; }
    ZZn12& operator+=(const ZZn12& x) {a[0]+=x.a[0]; a[1]+=x.a[1]; a[2]+=x.a[2];
                                     a[3]+=x.a[3]; a[4]+=x.a[4]; a[5]+=x.a[5]; 
                                     return *this; }
    ZZn12& operator-=(const ZZn2& x)  {a[0]-=x; return *this; }
    ZZn12& operator-=(const ZZn12& x) {a[0]-=x.a[0]; a[1]-=x.a[1]; a[2]-=x.a[2];
                                     a[3]-=x.a[3]; a[4]-=x.a[4]; a[5]-=x.a[5]; 
                                     return *this; }
    ZZn12& operator*=(const ZZn12&); 
    ZZn12& operator*=(const ZZn2& x) { a[0]*=x; a[1]*=x; a[2]*=x;
                                       a[3]*=x; a[4]*=x; a[5]*=x;  return *this;}
    ZZn12& operator*=(int x) { a[0]*=x; a[1]*=x; a[2]*=x;
                               a[3]*=x; a[4]*=x; a[5]*=x;  return *this;}
    ZZn12& operator/=(const ZZn12&); 
    ZZn12& operator/=(const ZZn2& x) { a[0]/=x; a[1]/=x; a[2]/=x;
                                     a[3]/=x; a[4]/=x; a[5]/=x; return *this; }
    ZZn12& invert(void);

    friend int  degree(const ZZn12&);
    friend ZZn12 operator+(const ZZn12&,const ZZn12&);
    friend ZZn12 operator+(const ZZn12&,const ZZn2&);
    friend ZZn12 operator-(const ZZn12&,const ZZn12&);
    friend ZZn12 operator-(const ZZn12&,const ZZn2&);
    friend ZZn12 operator-(const ZZn12&);

    friend ZZn12 operator*(const ZZn12&,const ZZn12&);
    friend ZZn12 operator*(const ZZn12&,const ZZn2&);
    friend ZZn12 operator*(const ZZn2&,const ZZn12&);

    friend ZZn12 operator*(int,const ZZn12&);
    friend ZZn12 operator*(const ZZn12&,int);

    friend ZZn12 operator/(const ZZn12&,const ZZn12&);
    friend ZZn12 operator/(const ZZn12&,const ZZn2&);

    friend ZZn12 pow(const ZZn12&,const Big&);
    friend ZZn12 pow(const ZZn12&,const Big*);
    friend ZZn12 pow(const ZZn12*,const ZZn12&,const Big&);
    friend ZZn12 pow(int,const ZZn12*,const Big*);
    friend void precompute(const ZZn12&,ZZn12 *);
    friend ZZn12 conj(const ZZn12&);

    friend ZZn12 randn12(void);        // random ZZn12

    friend BOOL operator==(const ZZn12& x,const ZZn12& y)
    {if (x.a[0]==y.a[0] && x.a[1]==y.a[1] && x.a[2]==y.a[2]
      && x.a[3]==y.a[3] && x.a[4]==y.a[4] && x.a[5]==y.a[5]) 
                                return TRUE; else return FALSE; }

    friend BOOL operator!=(const ZZn12& x,const ZZn12& y)
    {if (x.a[0]!=y.a[0] || x.a[1]!=y.a[1] || x.a[2]!=y.a[2]
      || x.a[3]!=y.a[3] || x.a[4]!=y.a[4] || x.a[5]!=y.a[5]) 
                                return TRUE; else return FALSE; }
#ifndef MR_NO_STANDARD_IO
    friend ostream& operator<<(ostream&,ZZn12&);
#endif
    ~ZZn12()  {}
};

#endif

