/*
 *   MIRACL compiler/hardware definitions - mirdef.h
 *   Copyright (c) 1988-2006 Shamus Software Ltd.
 */

#define MR_LITTLE_ENDIAN
#define MIRACL 64
#define mr_utype double
#define mr_dltype long double
#define MR_NOFULLWIDTH
#define MR_FP
#define MR_IBITS 32
#define MR_LBITS 32
#define mr_unsign32 unsigned int
#define mr_unsign64 unsigned long
#define MR_FP_ROUNDING
#define MR_MAGIC 6755399441055744.000000
#define MR_FLASH 52
#define MAXBASE 67108864.000000
#define MR_BITSINCHAR 8
