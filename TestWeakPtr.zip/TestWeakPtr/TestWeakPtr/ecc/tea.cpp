﻿// #ifdef __LINUX__
// #ifndef WIN32
// //#include "basedef.h" 
// #endif
// #endif


#define TXCOMMON_API
#include <string.h>
#include "Crypt.h"
#include <stdlib.h>

typedef unsigned long long   uint64_t;

static int xrand()
{
	static int holdrand = GetCurrentProcessId() * 100 + GetTickCount();
	return ( (holdrand = holdrand * 214013L + 2531011L) >> 16) & 0x7fff;
}

/*
void TeaEncryptECB(BYTE *pInBuf, BYTE *pKey, BYTE *pOutBuf);
void TeaDecryptECB(BYTE *pInBuf, BYTE *pKey, BYTE *pOutBuf);
*/

typedef unsigned long WORD32;

const WORD32 DELTA = 0x9e3779b9;

#define ROUNDS 16
#define LOG_ROUNDS 4

/*pOutBuffer、pInBuffer均为8byte, k为16byte*/
__forceinline void TeaEncryptECB(const BYTE *pInBuf, const WORD32 *k, BYTE *pOutBuf)
{
    WORD32 y, z;
    WORD32 sum;
    int i;

    /*plain-text is TCP/IP-endian;*/

    /*GetBlockBigEndian(in, y, z);*/
    y = ntohl(*((WORD32*)pInBuf));
    z = ntohl(*((WORD32*)(pInBuf+4)));
    /*TCP/IP network byte order (which is big-endian).has been done outside!*/

    sum = 0;
    for (i=0; i<ROUNDS; i++)
    {   
        sum += DELTA;
        y += (z << 4) + k[0] ^ z + sum ^ (z >> 5) + k[1];
        z += (y << 4) + k[2] ^ y + sum ^ (y >> 5) + k[3];
    }

    *((WORD32*)pOutBuf) = htonl(y);
    *((WORD32*)(pOutBuf+4)) = htonl(z);


    /*now encrypted buf is TCP/IP-endian;*/
}

/*pOutBuffer、pInBuffer均为8byte, k为16byte*/
__forceinline void TeaDecryptECB(const BYTE *pInBuf, const WORD32 *k, BYTE *pOutBuf)
{
    WORD32 y, z, sum;
    int i;

    /*now encrypted buf is TCP/IP-endian;*/
    /*TCP/IP network byte order (which is big-endian).*/
    y = ntohl(*((WORD32*)pInBuf));
    z = ntohl(*((WORD32*)(pInBuf+4)));

    /*now key is TCP/IP-endian; has been done outside!*/

    sum = DELTA << LOG_ROUNDS;
    for (i=0; i<ROUNDS; i++)
    {
        z -= (y << 4) + k[2] ^ y + sum ^ (y >> 5) + k[3]; 
        y -= (z << 4) + k[0] ^ z + sum ^ (z >> 5) + k[1];
        sum -= DELTA;
    }

    *((WORD32*)pOutBuf) = htonl(y);
    *((WORD32*)(pOutBuf+4)) = htonl(z);

    /*now plain-text is TCP/IP-endian;*/
}

#if 0

/*pOutBuffer、pInBuffer均为8byte, pKey为16byte*/
inline void TeaEncryptECB3(const BYTE *pInBuf, const BYTE *pKey, BYTE *pOutBuf)
{
	WORD32 y, z;
	WORD32 sum;
	WORD32 k[4];
	int i;

	/*plain-text is TCP/IP-endian;*/

	/*GetBlockBigEndian(in, y, z);*/
	y = ntohl(*((WORD32*)pInBuf));
	z = ntohl(*((WORD32*)(pInBuf+4)));
	/*TCP/IP network byte order (which is big-endian).*/

	for ( i = 0; i<4; i++)
	{
		/*now key is TCP/IP-endian;*/
		k[i] = ntohl(*((WORD32*)(pKey+i*4)));
	}

	sum = 0;
	for (i=0; i<13; i++)
	{   
		sum += DELTA;
		y += (z << 4) + k[0] ^ z + sum ^ (z >> 5) + k[1];
		z += (y << 4) + k[2] ^ y + sum ^ (y >> 5) + k[3];
	}



	*((WORD32*)pOutBuf) = htonl(y);
	*((WORD32*)(pOutBuf+4)) = htonl(z);


	/*now encrypted buf is TCP/IP-endian;*/
}




/*pOutBuffer、pInBuffer均为8byte, pKey为16byte*/
inline void TeaDecryptECB3(const BYTE *pInBuf, const BYTE *pKey, BYTE *pOutBuf)
{
	WORD32 y, z, sum;
	WORD32 k[4];
	int i;

	/*now encrypted buf is TCP/IP-endian;*/
	/*TCP/IP network byte order (which is big-endian).*/
	y = ntohl(*((WORD32*)pInBuf));
	z = ntohl(*((WORD32*)(pInBuf+4)));

	for ( i=0; i<4; i++)
	{
		/*key is TCP/IP-endian;*/
		k[i] = ntohl(*((WORD32*)(pKey+i*4)));
	}

	/*13=8+5*/
	sum = DELTA << 3;
	for (i=1; i<=5; i++)
	{
		sum += DELTA;
	}


	for (i=0; i<13; i++)
	{
		z -= (y << 4) + k[2] ^ y + sum ^ (y >> 5) + k[3]; 
		y -= (z << 4) + k[0] ^ z + sum ^ (z >> 5) + k[1];
		sum -= DELTA;
	}

	*((WORD32*)pOutBuf) = htonl(y);
	*((WORD32*)(pOutBuf+4)) = htonl(z);

	/*now plain-text is TCP/IP-endian;*/
}
#endif  // 0



#define SALT_LEN 2
#define ZERO_LEN 7

/*pKey为16byte*/
/*
输入:pInBuf为需加密的明文部分(Body),nInBufLen为pInBuf长度;
输出:pOutBuf为密文格式,pOutBufLen为pOutBuf的长度是8byte的倍数;
*/
/*TEA加密算法,CBC模式*/
/*密文格式:PadLen(1byte)+Padding(var,0-7byte)+Salt(2byte)+Body(var byte)+Zero(7byte)*/
void oi_symmetry_encrypt(const BYTE* pInBuf, int nInBufLen, const BYTE* pKey, BYTE* pOutBuf, int *pOutBufLen)
{

	int nPadSaltBodyZeroLen/*PadLen(1byte)+Salt+Body+Zero的长度*/;
	int nPadlen;
	BYTE src_buf[8], zero_iv[8], *iv_buf;
	int src_i, i, j;
    WORD32 k[4];

    for ( i=0; i<4; i++)
    {
        /*key is TCP/IP-endian;*/
        k[i] = ntohl(*((WORD32*)(pKey+i*4)));
    }

	/*根据Body长度计算PadLen,最小必需长度必需为8byte的整数倍*/
	nPadSaltBodyZeroLen = nInBufLen/*Body长度*/+1+SALT_LEN+ZERO_LEN/*PadLen(1byte)+Salt(2byte)+Zero(7byte)*/;
	nPadlen=nPadSaltBodyZeroLen%8;
	if(nPadlen) /*len=nSaltBodyZeroLen%8*/
	{
		/*模8余0需补0,余1补7,余2补6,...,余7补1*/
		nPadlen=8-nPadlen;
	}

	/*加密第一块数据(8byte),取前面10byte*/
	src_buf[0] = ((BYTE)xrand()) & 0x0f8/*最低三位存PadLen,清零*/ | (BYTE)nPadlen;
	src_i = 1; /*src_i指向src_buf下一个位置*/

	while(nPadlen--)
		src_buf[src_i++]=(BYTE)xrand(); /*Padding*/

	/*come here, i must <= 8*/

	memset(zero_iv, 0, 8);
	iv_buf = zero_iv; /*make iv*/

	*pOutBufLen = 0; /*init OutBufLen*/

	for (i=1;i<=SALT_LEN;) /*Salt(2byte)*/
	{
		if (src_i<8)
		{
			src_buf[src_i++]=(BYTE)xrand();
			i++; /*i inc in here*/
		}

		if (src_i==8)
		{
			/*src_i==8*/

			for (j=0;j<8;j++) /*CBC XOR*/
				src_buf[j]^=iv_buf[j];
			/*pOutBuffer、pInBuffer均为8byte, pKey为16byte*/
			TeaEncryptECB(src_buf, k, pOutBuf);
			src_i=0;
			iv_buf=pOutBuf;
			*pOutBufLen+=8;
			pOutBuf+=8;
		}
	}

	/*src_i指向src_buf下一个位置*/

	while(nInBufLen)
	{
		if (src_i<8)
		{
			src_buf[src_i++]=*(pInBuf++);
			nInBufLen--;
		}

		if (src_i==8)
		{
			/*src_i==8*/

			for (i=0;i<8;i++) /*CBC XOR*/
				src_buf[i]^=iv_buf[i];
			/*pOutBuffer、pInBuffer均为8byte, pKey为16byte*/
			TeaEncryptECB(src_buf, k, pOutBuf);
			src_i=0;
			iv_buf=pOutBuf;
			*pOutBufLen+=8;
			pOutBuf+=8;
		}
	}

	/*src_i指向src_buf下一个位置*/

	for (i=1;i<=ZERO_LEN;)
	{
		if (src_i<8)
		{
			src_buf[src_i++]=0;
			i++; /*i inc in here*/
		}

		if (src_i==8)
		{
			/*src_i==8*/

			for (j=0;j<8;j++) /*CBC XOR*/
				src_buf[j]^=iv_buf[j];
			/*pOutBuffer、pInBuffer均为8byte, pKey为16byte*/
			TeaEncryptECB(src_buf, k, pOutBuf);
			src_i=0;
			iv_buf=pOutBuf;
			*pOutBufLen+=8;
			pOutBuf+=8;
		}
	}

}

/*pKey为16byte*/
/*
输入:pInBuf为密文格式,nInBufLen为pInBuf的长度是8byte的倍数;
输出:pOutBuf为明文(Body),pOutBufLen为pOutBuf的长度;
返回值:如果格式正确返回TRUE;
*/
/*TEA解密算法,CBC模式*/
/*密文格式:PadLen(1byte)+Padding(var,0-7byte)+Salt(2byte)+Body(var byte)+Zero(7byte)*/
BOOL oi_symmetry_decrypt(const BYTE* pInBuf, int nInBufLen, const BYTE* pKey, BYTE* pOutBuf, int *pOutBufLen)
{

	int nPadLen, nPlainLen;
	BYTE dest_buf[8];
	const BYTE *iv_buf;
	int dest_i, i, j;
    WORD32 k[4];

	if ((nInBufLen%8) || (nInBufLen<16)) return FALSE;

    for ( i=0; i<4; i++)
    {
        /*key is TCP/IP-endian;*/
        k[i] = ntohl(*((WORD32*)(pKey+i*4)));
    }

	TeaDecryptECB(pInBuf, k, dest_buf);

	nPadLen = dest_buf[0] & 0x7/*只要最低三位*/;

	/*密文格式:PadLen(1byte)+Padding(var,0-7byte)+Salt(2byte)+Body(var byte)+Zero(7byte)*/
	i = nInBufLen-1/*PadLen(1byte)*/-nPadLen-SALT_LEN-ZERO_LEN; /*明文长度*/
	if (*pOutBufLen<i) return FALSE;
	*pOutBufLen = i;
	if (*pOutBufLen < 0) return FALSE;


	iv_buf = pInBuf; /*init iv*/
	nInBufLen -= 8;
	pInBuf += 8;

	dest_i=1; /*dest_i指向dest_buf下一个位置*/


	/*把Padding滤掉*/
	dest_i+=nPadLen;

	/*dest_i must <=8*/

	/*把Salt滤掉*/
	for (i=1; i<=SALT_LEN;)
	{
		if (dest_i<8)
		{
			dest_i++;
			i++;
		}

		if (dest_i==8)
		{
			/*dest_i==8*/
			TeaDecryptECB(pInBuf, k, dest_buf);
			for (j=0; j<8; j++)
				dest_buf[j]^=iv_buf[j];

			iv_buf = pInBuf;
			nInBufLen -= 8;
			pInBuf += 8;

			dest_i=0; /*dest_i指向dest_buf下一个位置*/
		}
	}

	/*还原明文*/

	nPlainLen=*pOutBufLen;
	while (nPlainLen)
	{
		if (dest_i<8)
		{
			*(pOutBuf++)=dest_buf[dest_i++];
			nPlainLen--;
		}
		else if (dest_i==8)
		{
			/*dest_i==8*/
			TeaDecryptECB(pInBuf, k, dest_buf);
			for (i=0; i<8; i++)
				dest_buf[i]^=iv_buf[i];

			iv_buf = pInBuf;
			nInBufLen -= 8;
			pInBuf += 8;

			dest_i=0; /*dest_i指向dest_buf下一个位置*/
		}
	}

	/*校验Zero*/
	for (i=1;i<=ZERO_LEN;)
	{
		if (dest_i<8)
		{
			if(dest_buf[dest_i++]) return FALSE;
			i++;
		}
		else if (dest_i==8)
		{
			/*dest_i==8*/
			TeaDecryptECB(pInBuf, k, dest_buf);
			for (j=0; j<8; j++)
				dest_buf[j]^=iv_buf[j];

			iv_buf = pInBuf;
			nInBufLen -= 8;
			pInBuf += 8;

			dest_i=0; /*dest_i指向dest_buf下一个位置*/
		}

	}

	return TRUE;
}

/* ///////////////////////////////////////////////////////////////////////////////////////////// */

/*pKey为16byte*/
/*
输入:nInBufLen为需加密的明文部分(Body)长度;
输出:返回为加密后的长度(是8byte的倍数);
*/
/*TEA加密算法,CBC模式*/
/*密文格式:PadLen(1byte)+Padding(var,0-7byte)+Salt(2byte)+Body(var byte)+Zero(7byte)*/
int oi_symmetry_encrypt2_len(int nInBufLen)
{

	int nPadSaltBodyZeroLen/*PadLen(1byte)+Salt+Body+Zero的长度*/;
	int nPadlen;

	/*根据Body长度计算PadLen,最小必需长度必需为8byte的整数倍*/
	nPadSaltBodyZeroLen = nInBufLen/*Body长度*/+1+SALT_LEN+ZERO_LEN/*PadLen(1byte)+Salt(2byte)+Zero(7byte)*/;
	nPadlen=nPadSaltBodyZeroLen%8;
	if(nPadlen) /*len=nSaltBodyZeroLen%8*/
	{
		/*模8余0需补0,余1补7,余2补6,...,余7补1*/
		nPadlen=8-nPadlen;
	}

	return nPadSaltBodyZeroLen+nPadlen;
}


/*pKey为16byte*/
/*
输入:pInBuf为需加密的明文部分(Body),nInBufLen为pInBuf长度;
输出:pOutBuf为密文格式,pOutBufLen为pOutBuf的长度是8byte的倍数;
*/
/*TEA加密算法,CBC模式*/
/*密文格式:PadLen(1byte)+Padding(var,0-7byte)+Salt(2byte)+Body(var byte)+Zero(7byte)*/
void oi_symmetry_encrypt2(const BYTE* pInBuf, int nInBufLen, const BYTE* pKey, BYTE* pOutBuf, int *pOutBufLen)
{
    int nPadSaltBodyZeroLen/*PadLen(1byte)+Salt+Body+Zero的长度*/;
    int nPadlen;
    BYTE src_buf[8], iv_plain[8], *iv_crypt;
    int src_i, i, n;
    WORD32 k[4];

    for ( i=0; i<4; i++)
    {
        /*key is TCP/IP-endian;*/
        k[i] = ntohl(*((WORD32*)(pKey+i*4)));
    }

    /*根据Body长度计算PadLen,最小必需长度必需为8byte的整数倍*/
    nPadSaltBodyZeroLen = nInBufLen/*Body长度*/+1+SALT_LEN+ZERO_LEN/*PadLen(1byte)+Salt(2byte)+Zero(7byte)*/;
    nPadlen=nPadSaltBodyZeroLen%8;
    if(nPadlen) /*len=nSaltBodyZeroLen%8*/
    {
        /*模8余0需补0,余1补7,余2补6,...,余7补1*/
        nPadlen=8-nPadlen;
    }

    /*加密第一块数据(8byte),取前面10byte*/
    src_buf[0] = ((BYTE)xrand()) & 0x0f8/*最低三位存PadLen,清零*/ | (BYTE)nPadlen;
    src_i = 1; /*src_i指向src_buf下一个位置*/

    while(nPadlen--)
        src_buf[src_i++]=(BYTE)xrand(); /*Padding*/

    /*come here, src_i must <= 8*/

    for ( i=0; i<8; i++)
        iv_plain[i] = 0;
    iv_crypt = iv_plain; /*make zero iv*/

    *pOutBufLen = 0; /*init OutBufLen*/

    for (i=1;i<=SALT_LEN;) /*Salt(2byte)*/
    {
        if (src_i<8)
        {
            src_buf[src_i++]=(BYTE)xrand();
            i++; /*i inc in here*/
        }

        if (src_i==8)
        {
            /*src_i==8*/

            /*加密前异或前8个byte的密文(iv_crypt指向的)*/
            *(uint64_t *)src_buf ^= *(uint64_t *)iv_crypt;

            /*pOutBuffer、pInBuffer均为8byte, pKey为16byte*/
            /*加密*/
            TeaEncryptECB(src_buf, k, pOutBuf);

            /*加密后异或前8个byte的明文(iv_plain指向的)*/
            *(uint64_t *)pOutBuf ^= *(uint64_t *)iv_plain;

            /*保存当前的iv_plain*/
            *(uint64_t *)iv_plain = *(uint64_t *)src_buf;

            /*更新iv_crypt*/
            src_i=0;
            iv_crypt=pOutBuf;
            *pOutBufLen+=8;
            pOutBuf+=8;
        }
    }


    /*src_i指向src_buf下一个位置*/

    if (src_i > 0 && nInBufLen > 8 - src_i)
    {
        while (src_i < 8)
        {
            src_buf[src_i++] = *(pInBuf++);
            nInBufLen--;
        }

        /*加密前异或前8个byte的密文(iv_crypt指向的)*/
        *(uint64_t *)src_buf ^= *(uint64_t *)iv_crypt;

        /*pOutBuffer、pInBuffer均为8byte, pKey为16byte*/
        TeaEncryptECB(src_buf, k, pOutBuf);

        /*加密后异或前8个byte的明文(iv_plain指向的)*/
        *(uint64_t *)pOutBuf ^= *(uint64_t *)iv_plain;

        /*保存当前的iv_plain*/
        *(uint64_t *)iv_plain = *(uint64_t *)src_buf;

        src_i=0;
        iv_crypt=pOutBuf;
        *pOutBufLen+=8;
        pOutBuf+=8;
    }
    n = nInBufLen / 8;
    for (i = 0; i < n; i++)
    {
        *(uint64_t *)src_buf = *(uint64_t *)pInBuf;
        pInBuf += 8;

        /*加密前异或前8个byte的密文(iv_crypt指向的)*/
        *(uint64_t *)src_buf ^= *(uint64_t *)iv_crypt;

        /*pOutBuffer、pInBuffer均为8byte, pKey为16byte*/
        TeaEncryptECB(src_buf, k, pOutBuf);

        /*加密后异或前8个byte的明文(iv_plain指向的)*/
        *(uint64_t *)pOutBuf ^= *(uint64_t *)iv_plain;

        /*保存当前的iv_plain*/
        *(uint64_t *)iv_plain = *(uint64_t *)src_buf;

        iv_crypt=pOutBuf;
        pOutBuf+=8;
    }
    *pOutBufLen += 8 * n;

    /*src_i指向src_buf下一个位置*/
    /*Zero填充长度要小于8字节，所以一次block处理即可:不够8位的默认填充为0*/
    *(uint64_t *)src_buf = 0;
    n = nInBufLen % 8;
    for (i = 0; i < n; i++)
    {
        src_buf[i] = *(pInBuf++);
    }

    *(uint64_t *)src_buf ^= *(uint64_t *)iv_crypt;

    /*pOutBuffer、pInBuffer均为8byte, pKey为16byte*/
    TeaEncryptECB(src_buf, k, pOutBuf);

    /*加密后异或前8个byte的明文(iv_plain指向的)*/
    *(uint64_t *)pOutBuf ^= *(uint64_t *)iv_plain;

    /*保存当前的iv_plain*/
    *(uint64_t *)iv_plain = *(uint64_t *)src_buf;

    *pOutBufLen+=8;
}


/*pKey为16byte*/
/*
输入:pInBuf为密文格式,nInBufLen为pInBuf的长度是8byte的倍数; *pOutBufLen为接收缓冲区的长度
特别注意*pOutBufLen应预置接收缓冲区的长度!
输出:pOutBuf为明文(Body),pOutBufLen为pOutBuf的长度,至少应预留nInBufLen-10;
返回值:如果格式正确返回TRUE;
*/
/*TEA解密算法,CBC模式*/
/*密文格式:PadLen(1byte)+Padding(var,0-7byte)+Salt(2byte)+Body(var byte)+Zero(7byte)*/
BOOL oi_symmetry_decrypt2(const BYTE* pInBuf, int nInBufLen, const BYTE* pKey, BYTE* pOutBuf, int *pOutBufLen)
{
    int nPadLen, nPlainLen;
    BYTE dest_buf[8], zero_buf[8];
    const BYTE *iv_pre_crypt, *iv_cur_crypt;
    int dest_i, i;
    int nBufPos;
    nBufPos = 0;
    int n;
    WORD32 k[4];

    for ( i=0; i<4; i++)
    {
        /*key is TCP/IP-endian;*/
        k[i] = ntohl(*((WORD32*)(pKey+i*4)));
    }

    if ((nInBufLen%8) || (nInBufLen<16)) return FALSE;

    TeaDecryptECB(pInBuf, k, dest_buf);

    nPadLen = dest_buf[0] & 0x7/*只要最低三位*/;

    /*密文格式:PadLen(1byte)+Padding(var,0-7byte)+Salt(2byte)+Body(var byte)+Zero(7byte)*/
    i = nInBufLen-1/*PadLen(1byte)*/-nPadLen-SALT_LEN-ZERO_LEN; /*明文长度*/
    if ((*pOutBufLen<i) || (i<0)) return FALSE;
    *pOutBufLen = i;

    *(uint64_t *)zero_buf = 0;

    iv_pre_crypt = zero_buf;
    iv_cur_crypt = pInBuf; /*init iv*/

    pInBuf += 8;
    nBufPos += 8;

    dest_i=1; /*dest_i指向dest_buf下一个位置*/


    /*把Padding滤掉*/
    dest_i+=nPadLen;

    /*dest_i must <=8*/

    /*把Salt滤掉*/
    for (i=1; i<=SALT_LEN;)
    {
        if (dest_i<8)
        {
            dest_i++;
            i++;
        }
        else if (dest_i==8)
        {
            /*解开一个新的加密块*/

            /*改变前一个加密块的指针*/
            iv_pre_crypt = iv_cur_crypt;
            iv_cur_crypt = pInBuf; 

            /*异或前一块明文(在dest_buf[]中)*/
            if (nBufPos + 7 >= nInBufLen)
                return FALSE;
            *(uint64_t *)dest_buf ^= *(uint64_t *)pInBuf;

            /*dest_i==8*/
            TeaDecryptECB(dest_buf, k, dest_buf);

            /*在取出的时候才异或前一块密文(iv_pre_crypt)*/


            pInBuf += 8;
            nBufPos += 8;

            dest_i=0; /*dest_i指向dest_buf下一个位置*/
        }
    }

    /*还原明文*/
    nPlainLen=*pOutBufLen;
    if (dest_i > 0 && nPlainLen > 8 - dest_i)
    {
        while (dest_i < 8)
        {
            *(pOutBuf++)=dest_buf[dest_i]^iv_pre_crypt[dest_i];
            dest_i++;
            nPlainLen--;
        }

        /*dest_i==8*/

        /*改变前一个加密块的指针*/
        iv_pre_crypt = iv_cur_crypt;
        iv_cur_crypt = pInBuf; 

        /*解开一个新的加密块*/

        /*异或前一块明文(在dest_buf[]中)*/
        if (nBufPos + 7 >= nInBufLen)
            return FALSE;
        *(uint64_t *)dest_buf ^= *(uint64_t *)pInBuf;

        TeaDecryptECB(dest_buf, k, dest_buf);

        /*在取出的时候才异或前一块密文(iv_pre_crypt)*/

        pInBuf += 8;
        nBufPos += 8;

        dest_i=0; /*dest_i指向dest_buf下一个位置*/

        /*获取当前块中的out数据*/
        if (nPlainLen >= 8)   /*当nPlainLen大于等于8个字节时，则整个块拷贝；否则只拷贝输出部分*/
        {
            *(uint64_t *)pOutBuf = (*(uint64_t *)dest_buf) ^ (*(uint64_t *)iv_pre_crypt);
            pOutBuf += 8;
            nPlainLen -= 8;
            dest_i=8;
        }
        else
        {
            while (nPlainLen)
            {
                if (dest_i<8)
                {
                    *(pOutBuf++)=dest_buf[dest_i]^iv_pre_crypt[dest_i];
                    dest_i++;
                    nPlainLen--;
                }
            }
        }
    }

    /*后面部分就可以切块处理*/
    n = nPlainLen / 8;

    /*数据溢出检查*/
    if (nBufPos + 8*n > nInBufLen)
        return FALSE;
    for (i = 0; i < n; i++)
    {
        /*dest_i==8*/

        /*改变前一个加密块的指针*/
        iv_pre_crypt = iv_cur_crypt;
        iv_cur_crypt = pInBuf; 

        /*解开一个新的加密块*/

        /*异或前一块明文(在dest_buf[]中)*/
        *(uint64_t *)dest_buf ^= *(uint64_t *)pInBuf;

        TeaDecryptECB(dest_buf, k, dest_buf);

        /*在取出的时候才异或前一块密文(iv_pre_crypt)*/
        *(uint64_t *)pOutBuf = (*(uint64_t *)dest_buf) ^ (*(uint64_t *)iv_pre_crypt);
        pOutBuf += 8;

        pInBuf += 8;
    }
    nBufPos += 8*n;
    /*如果n>0 要重置dest_i*/
    if (n > 0)
    {
        dest_i=8; /*dest_i指向dest_buf下一个位置*/
    }

    n = nPlainLen % 8;
    /*最后一个处理块*/
    if (n > 0)
    {
        /*改变前一个加密块的指针*/
        iv_pre_crypt = iv_cur_crypt;
        iv_cur_crypt = pInBuf; 

        /*异或前一块明文(在dest_buf[]中)*/
        if (nBufPos + 7 >= nInBufLen)
            return FALSE;
        *(uint64_t *)dest_buf ^= *(uint64_t *)pInBuf;

        TeaDecryptECB(dest_buf, k, dest_buf);

        pInBuf += 8;
        nBufPos += 8;
        dest_i=0; /*dest_i指向dest_buf下一个位置*/

        /*剩余的内容buf*/
        for (i = 0; i < n; i++)
        {
            *(pOutBuf++)=dest_buf[dest_i]^iv_pre_crypt[dest_i];
            dest_i++;
        }
        /*校验Zero*/
        while (dest_i<8)
        {
            if(dest_buf[dest_i]^iv_pre_crypt[dest_i]) return FALSE;
            dest_i++;
        }
    }
    else
    {
        /*校验Zero*/
        while (dest_i<8)
        {
            if(dest_buf[dest_i]^iv_pre_crypt[dest_i]) return FALSE;
            dest_i++;
        }
    }

    return TRUE;
}


#if 0
/*不编译*/

/* ///////////////////////////////////////////////////////////////////////////////////////////// */

/*pKey为16byte*/
/*
输入:nInBufLen为需加密的明文部分(Body)长度;
输出:返回为加密后的长度(是8byte的倍数);
*/
/*TEA加密算法,CBC模式*/
/*密文格式:PadLen(1byte)+Padding(var,0-7byte)+Salt(2byte)+Body(var byte)+Zero(7byte)*/
int qq_symmetry_encrypt3_len(int nInBufLen)
{

	int nPadSaltBodyZeroLen/*PadLen(1byte)+Salt+Body+Zero的长度*/;
	int nPadlen;

	/*根据Body长度计算PadLen,最小必需长度必需为8byte的整数倍*/
	nPadSaltBodyZeroLen = nInBufLen/*Body长度*/+1+SALT_LEN+ZERO_LEN/*PadLen(1byte)+Salt(2byte)+Zero(7byte)*/;
	nPadlen=nPadSaltBodyZeroLen%8;
	if(nPadlen) /*len=nSaltBodyZeroLen%8*/
	{
		/*模8余0需补0,余1补7,余2补6,...,余7补1*/
		nPadlen=8-nPadlen;
	}

	return nPadSaltBodyZeroLen+nPadlen;
}

/*pKey为16byte*/
/*
输入:pInBuf为需加密的明文部分(Body),nInBufLen为pInBuf长度;
输出:pOutBuf为密文格式,pOutBufLen为pOutBuf的长度是8byte的倍数;
*/
/*TEA加密算法,CBC模式*/
/*密文格式:PadLen(1byte)+Padding(var,0-7byte)+Salt(2byte)+Body(var byte)+Zero(7byte)*/
/*
Hash(Hash(chMainVerc1, uin1), Hash(c2,uin2)) ^ pKey
*/
inline void qq_symmetry_encrypt3(const BYTE* pInBuf, int nInBufLen, DWORD dwUin, const BYTE* pKey, BYTE* pOutBuf, int *pOutBufLen)
{

	int nPadSaltBodyZeroLen/*PadLen(1byte)+Salt+Body+Zero的长度*/;
	int nPadlen;
	BYTE src_buf[8], iv_plain[8], *iv_crypt, key[16], temp_buf[32];
	int src_i, i, j;

	/*根据Body长度计算PadLen,最小必需长度必需为8byte的整数倍*/
	nPadSaltBodyZeroLen = nInBufLen/*Body长度*/+1+SALT_LEN+ZERO_LEN/*PadLen(1byte)+Salt(2byte)+Zero(7byte)*/;
	if(nPadlen=nPadSaltBodyZeroLen%8) /*len=nSaltBodyZeroLen%8*/
	{
		/*模8余0需补0,余1补7,余2补6,...,余7补1*/
		nPadlen=8-nPadlen;
	}

	/*加密第一块数据(8byte),取前面10byte*/
	src_buf[0] = ((BYTE)xrand()) & 0x0f8/*最低三位存PadLen,清零*/ | (BYTE)nPadlen;
	src_i = 1; /*src_i指向src_buf下一个位置*/

	while(nPadlen--)
		src_buf[src_i++]=(BYTE)xrand(); /*Padding*/

	/*come here, src_i must <= 8*/

	for ( i=0; i<8; i++)
		iv_plain[i] = 0;
	iv_crypt = iv_plain; /*make zero iv*/

	*pOutBufLen = 0; /*init OutBufLen*/

	/*************************************/
	dwUin = htonl(dwUin);
	/*
	Hash(Hash(chMainVerc1, uin1), Hash(c2,uin2))
	1、Hash(chMainVerc1, uin1)
	2、把Hash(chMainVerc1, uin1)传给外面函数，算出Hash(Hash(chMainVerc1, uin1), Hash(c2,uin2)) ^ Hash(c2,uin2)
	3、算出Hash(Hash(chMainVerc1, uin1), Hash(c2,uin2))
	4、算出Hash(Hash(chMainVerc1, uin1), Hash(c2,uin2)) ^ pKey
	*/
	temp_buf[0] = (BYTE)GetQqMainVer();
	*(DWORD*)&temp_buf[1] = dwUin;
	Md5HashBuffer( key, temp_buf, sizeof(BYTE)+sizeof(DWORD));
	theApp.V3Hash(/*int t1*/nPadSaltBodyZeroLen, key, /*DWORD t2*/*(const DWORD*)src_buf, /*CString t3*/theApp.m_strTempHostName,
		/*const CString t4*/theApp.m_strMsgDlgAdServerIP, /*BYTE *pOutBuf*/&temp_buf[14],
		/*short *t5*/&src_i, nPadlen);

	temp_buf[3] = (BYTE)GetQqSubVer();
	*(DWORD*)&temp_buf[4] = dwUin;
	Md5HashBuffer( key, &temp_buf[3], sizeof(BYTE)+sizeof(DWORD));

	for (i=0; i<sizeof(key); i++)
	{
		key[i] ^= *(pKey+i)^temp_buf[14+i]; /*a^b^c = a^(b^c)*/
	}
	/*************************************/


	for (i=1;i<=SALT_LEN;) /*Salt(2byte)*/
	{
		if (src_i<8)
		{
			src_buf[src_i++]=(BYTE)xrand();
			i++; /*i inc in here*/
		}

		if (src_i==8)
		{
			/*src_i==8*/

			for (j=0;j<8;j++) /*加密前异或前8个byte的密文(iv_crypt指向的)*/
				src_buf[j]^=iv_crypt[j];

			/*pOutBuffer、pInBuffer均为8byte, pKey为16byte*/
			/*加密*/
			TeaEncryptECB3(src_buf, key, pOutBuf);

			for (j=0;j<8;j++) /*加密后异或前8个byte的明文(iv_plain指向的)*/
				pOutBuf[j]^=iv_plain[j];

			/*保存当前的iv_plain*/
			for (j=0;j<8;j++)
				iv_plain[j]=src_buf[j];

			/*更新iv_crypt*/
			src_i=0;
			iv_crypt=pOutBuf;
			*pOutBufLen+=8;
			pOutBuf+=8;
		}
	}

	/*src_i指向src_buf下一个位置*/

	while(nInBufLen)
	{
		if (src_i<8)
		{
			src_buf[src_i++]=*(pInBuf++);
			nInBufLen--;
		}

		if (src_i==8)
		{
			/*src_i==8*/

			for (j=0;j<8;j++) /*加密前异或前8个byte的密文(iv_crypt指向的)*/
				src_buf[j]^=iv_crypt[j];
			/*pOutBuffer、pInBuffer均为8byte, pKey为16byte*/
			TeaEncryptECB3(src_buf, key, pOutBuf);

			for (j=0;j<8;j++) /*加密后异或前8个byte的明文(iv_plain指向的)*/
				pOutBuf[j]^=iv_plain[j];

			/*保存当前的iv_plain*/
			for (j=0;j<8;j++)
				iv_plain[j]=src_buf[j];

			src_i=0;
			iv_crypt=pOutBuf;
			*pOutBufLen+=8;
			pOutBuf+=8;
		}
	}

	/*src_i指向src_buf下一个位置*/

	for (i=1;i<=ZERO_LEN;)
	{
		if (src_i<8)
		{
			src_buf[src_i++]=0;
			i++; /*i inc in here*/
		}

		if (src_i==8)
		{
			/*src_i==8*/

			for (j=0;j<8;j++) /*加密前异或前8个byte的密文(iv_crypt指向的)*/
				src_buf[j]^=iv_crypt[j];
			/*pOutBuffer、pInBuffer均为8byte, pKey为16byte*/
			TeaEncryptECB3(src_buf, key, pOutBuf);

			for (j=0;j<8;j++) /*加密后异或前8个byte的明文(iv_plain指向的)*/
				pOutBuf[j]^=iv_plain[j];

			/*保存当前的iv_plain*/
			for (j=0;j<8;j++)
				iv_plain[j]=src_buf[j];

			src_i=0;
			iv_crypt=pOutBuf;
			*pOutBufLen+=8;
			pOutBuf+=8;
		}
	}

}


/* #if 0 */
/*不编译*/


/*pKey为16byte*/
/*
输入:pInBuf为密文格式,nInBufLen为pInBuf的长度是8byte的倍数; *pOutBufLen为接收缓冲区的长度
特别注意*pOutBufLen应预置接收缓冲区的长度!
输出:pOutBuf为明文(Body),pOutBufLen为pOutBuf的长度,至少应预留nInBufLen-10;
返回值:如果格式正确返回TRUE;
*/
/*TEA解密算法,CBC模式*/
/*密文格式:PadLen(1byte)+Padding(var,0-7byte)+Salt(2byte)+Body(var byte)+Zero(7byte)*/
/*
Hash(Hash(chMainVerc1, uin1), Hash(c2,uin2)) ^ pKey
*/
inline BOOL qq_symmetry_decrypt3(const BYTE* pInBuf, int nInBufLen, BYTE chMainVer, BYTE chSubVer, DWORD dwUin, const BYTE* pKey, BYTE* pOutBuf, int *pOutBufLen)
{

	int nPadLen, nPlainLen;
	BYTE dest_buf[8], zero_buf[8], key[16], temp_buf[32];
	const BYTE *iv_pre_crypt, *iv_cur_crypt;
	int dest_i, i, j;
	const BYTE *pInBufBoundary;
	int nBufPos;
	nBufPos = 0;


	if ((nInBufLen%8) || (nInBufLen<16)) return FALSE;


	dwUin = htonl(dwUin);   
	/**************************************************/
	/*
	Hash(Hash(chMainVerc1, uin1), Hash(c2,uin2)) ^ pKey
	*/

	temp_buf[0] = chMainVer;
	*(DWORD*)&temp_buf[1] = dwUin;
	Md5HashBuffer( temp_buf, &temp_buf[0], sizeof(BYTE)+sizeof(DWORD));

	temp_buf[16] = chSubVer;
	*(DWORD*)&temp_buf[17] = dwUin;
	Md5HashBuffer( &temp_buf[16], &temp_buf[16], sizeof(BYTE)+sizeof(DWORD));

	Md5HashBuffer( key, &temp_buf[0], sizeof(temp_buf));

	for (i=0; i<sizeof(key); i++)
	{
		key[i] ^= *(pKey+i);
	}

	/**************************************************/

	TeaDecryptECB3(pInBuf, key, dest_buf);

	nPadLen = dest_buf[0] & 0x7/*只要最低三位*/;

	/*密文格式:PadLen(1byte)+Padding(var,0-7byte)+Salt(2byte)+Body(var byte)+Zero(7byte)*/
	i = nInBufLen-1/*PadLen(1byte)*/-nPadLen-SALT_LEN-ZERO_LEN; /*明文长度*/
	if ((*pOutBufLen<i) || (i<0)) return FALSE;
	*pOutBufLen = i;

	pInBufBoundary = pInBuf + nInBufLen; /*输入缓冲区的边界，下面不能pInBuf>=pInBufBoundary*/


	for ( i=0; i<8; i++)
		zero_buf[i] = 0;

	iv_pre_crypt = zero_buf;
	iv_cur_crypt = pInBuf; /*init iv*/

	pInBuf += 8;
	nBufPos += 8;

	dest_i=1; /*dest_i指向dest_buf下一个位置*/


	/*把Padding滤掉*/
	dest_i+=nPadLen;

	/*dest_i must <=8*/

	/*把Salt滤掉*/
	for (i=1; i<=SALT_LEN;)
	{
		if (dest_i<8)
		{
			dest_i++;
			i++;
		}
		else if (dest_i==8)
		{
			/*解开一个新的加密块*/

			/*改变前一个加密块的指针*/
			iv_pre_crypt = iv_cur_crypt;
			iv_cur_crypt = pInBuf; 

			/*异或前一块明文(在dest_buf[]中)*/
			for (j=0; j<8; j++)
			{
				if( (nBufPos + j) >= nInBufLen)
					return FALSE;
				dest_buf[j]^=pInBuf[j];
			}

			/*dest_i==8*/
			TeaDecryptECB3(dest_buf, key, dest_buf);

			/*在取出的时候才异或前一块密文(iv_pre_crypt)*/


			pInBuf += 8;
			nBufPos += 8;

			dest_i=0; /*dest_i指向dest_buf下一个位置*/
		}
	}

	/*还原明文*/

	nPlainLen=*pOutBufLen;
	while (nPlainLen)
	{
		if (dest_i<8)
		{
			*(pOutBuf++)=dest_buf[dest_i]^iv_pre_crypt[dest_i];
			dest_i++;
			nPlainLen--;
		}
		else if (dest_i==8)
		{
			/*dest_i==8*/

			/*改变前一个加密块的指针*/
			iv_pre_crypt = iv_cur_crypt;
			iv_cur_crypt = pInBuf; 

			/*解开一个新的加密块*/

			/*异或前一块明文(在dest_buf[]中)*/
			for (j=0; j<8; j++)
			{
				if( (nBufPos + j) >= nInBufLen)
					return FALSE;
				dest_buf[j]^=pInBuf[j];
			}

			TeaDecryptECB3(dest_buf, key, dest_buf);

			/*在取出的时候才异或前一块密文(iv_pre_crypt)*/


			pInBuf += 8;
			nBufPos += 8;

			dest_i=0; /*dest_i指向dest_buf下一个位置*/
		}
	}

	/*校验Zero*/
	for (i=1;i<=ZERO_LEN;)
	{
		if (dest_i<8)
		{
			if(dest_buf[dest_i]^iv_pre_crypt[dest_i]) return FALSE;
			dest_i++;
			i++;
		}
		else if (dest_i==8)
		{
			/*改变前一个加密块的指针*/
			iv_pre_crypt = iv_cur_crypt;
			iv_cur_crypt = pInBuf; 

			/*解开一个新的加密块*/

			/*异或前一块明文(在dest_buf[]中)*/
			for (j=0; j<8; j++)
			{
				if( (nBufPos + j) >= nInBufLen)
					return FALSE;
				dest_buf[j]^=pInBuf[j];
			}

			TeaDecryptECB3(dest_buf, key, dest_buf);

			/*在取出的时候才异或前一块密文(iv_pre_crypt)*/


			pInBuf += 8;
			nBufPos += 8;
			dest_i=0; /*dest_i指向dest_buf下一个位置*/
		}

	}

	return TRUE;
}
#endif  // 0

//Added by Link , 支持4 bytes单位加密的tea

//加密
//short* v:data 4 bytes
//short* k:key 8 bytes
void _4bytesEncryptAFrame(short *v, short *k)
{
	short m_n4BytesScheduleDelta=0x325f;
	///unsigned long m_nScheduleDelta=0x19099830;

	short y=v[0],z=v[1], sum=0,   /* set up */
		n=32;             
	while (n-->0)
	{                       /* basic cycle start */
		sum += m_n4BytesScheduleDelta;/* a key schedule constant */
		y += (z<<4)+k[0] ^ z+sum ^ (z>>5)+k[1] ;
		z += (y<<4)+k[2] ^ y+sum ^ (y>>5)+k[3] ;   /* end cycle */      
	} 
	v[0]=y ; v[1]=z ; 
}

//解密
//short* v:data 4 bytes
//short* k:key 8 bytes
void _4bytesDecryptAFrame(short *v, short *k)
{
	short m_n4BytesScheduleDelta=0x325f;

	short n=32, sum, y=v[0], z=v[1];
	sum=m_n4BytesScheduleDelta<<5 ;
	/* start cycle */
	while (n-->0) {
		z-= (y<<4)+k[2] ^ y+sum ^ (y>>5)+k[3] ; 
		y-= (z<<4)+k[0] ^ z+sum ^ (z>>5)+k[1] ;
		sum-=m_n4BytesScheduleDelta ;  
	}
	/* end cycle */
	v[0]=y ;
	v[1]=z ;
}
