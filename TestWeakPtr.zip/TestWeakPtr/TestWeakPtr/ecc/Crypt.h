﻿/** 
@file 
@brief		加解密. 实现下列算法: Hash算法: MD5,已实现. 对称算法: DES,未实现. 非对称算法: RSA,未实现
@version	2002-9-25 hyj  创建
@version	2005-4-07 yuyu 整理
*/

#pragma once

#define MD5_DIGEST_LENGTH	16
#define ENCRYPT_PADLEN		18
#define	CRYPT_KEY_SIZE		16

#define MD5_LBLOCK	16
// MD5数据结构
typedef struct MD5state_st
	{
	unsigned long A,B,C,D;
	unsigned long Nl,Nh;
	unsigned long data[MD5_LBLOCK];
	int num;
	} MD5_CTX;

void MD5_Init(MD5_CTX *c);
void MD5_Update(MD5_CTX *c, const register unsigned char *data, unsigned long len);
void MD5_Final(unsigned char *md, MD5_CTX *c);

/**@ingroup ov_Crypt
@{
*/
/// MD5 Hash函数
/** @param outBuffer out, Hash后的Buffer, 该Buffer的长度固定为MD5_DIGEST_LENGTH(16byte)
	@param inBuffer in, 原始buffer.
	@param length in, 原始buffer的长度, 接受长度为0的buffer
*/
void Md5HashBuffer( BYTE *outBuffer, const void *inBuffer, unsigned long length);


/// QQ对称加密第一代函数. (TEA加密算法,CBC模式). 密文格式:PadLen(1byte)+Padding(var,0-7byte)+Salt(2byte)+Body(var byte)+Zero(7byte)
/** @param pInBuf in,		需加密的明文部分(Body)
	@param nInBufLen in,	pInBuf长度
	@param pKey in,			加密Key, 长度固定为16Byte.
	@param pOutBuf out,		输出的密文
	@param pOutBufLen in out,	pOutBuf的长度. 长度是8byte的倍数,至少应预留nInBufLen+17;
*/
void oi_symmetry_encrypt(const BYTE* pInBuf, int nInBufLen, const BYTE* pKey, BYTE* pOutBuf, int *pOutBufLen);


/// QQ对称解密第一代函数. (TEA加密算法,CBC模式). 密文格式:PadLen(1byte)+Padding(var,0-7byte)+Salt(2byte)+Body(var byte)+Zero(7byte)
/** @param pInBuf in,		需解密的密文.
	@param nInBufLen in,	pInBuf长度. 8byte的倍数
	@param pKey in,			解密Key, 长度固定为16Byte.
	@param pOutBuf out,		输出的明文
	@param pOutBufLen in out,	pOutBuf的长度. 至少应预留nInBufLen-10
	@return BOOL,			如果格式正确返回TRUE
*/
BOOL oi_symmetry_decrypt(const BYTE* pInBuf, int nInBufLen, const BYTE* pKey, BYTE* pOutBuf, int *pOutBufLen);




//////////////////////////////////////////////////////////////////////////



/// QQ对称计算加密长度第二代函数. (TEA加密算法,CBC模式). 密文格式:PadLen(1byte)+Padding(var,0-7byte)+Salt(2byte)+Body(var byte)+Zero(7byte)
/** @param nInBufLen in,	nInBufLen为需加密的明文部分(Body)长度
	@return int,			返回为加密后的长度(是8byte的倍数)
*/
int oi_symmetry_encrypt2_len(int nInBufLen);


/// QQ对称加密第二代函数. (TEA加密算法,CBC模式). 密文格式:PadLen(1byte)+Padding(var,0-7byte)+Salt(2byte)+Body(var byte)+Zero(7byte)
/** @param pInBuf in,		需加密的明文部分(Body)
	@param nInBufLen in,	pInBuf长度
	@param pKey in,			加密Key, 长度固定为16Byte.
	@param pOutBuf out,		输出的密文
	@param pOutBufLen in out,	pOutBuf的长度. 长度是8byte的倍数,至少应预留nInBufLen+17;
*/
void oi_symmetry_encrypt2(const BYTE* pInBuf, int nInBufLen, const BYTE* pKey, BYTE* pOutBuf, int *pOutBufLen);

/// QQ对称解密第二代函数. (TEA加密算法,CBC模式). 密文格式:PadLen(1byte)+Padding(var,0-7byte)+Salt(2byte)+Body(var byte)+Zero(7byte)
/** @param pInBuf in,		需解密的密文.
	@param nInBufLen in,	pInBuf长度. 8byte的倍数
	@param pKey in,			解密Key, 长度固定为16Byte.
	@param pOutBuf out,		输出的明文
	@param pOutBufLen in out,	pOutBuf的长度. 至少应预留nInBufLen-10
	@return BOOL,			如果格式正确返回TRUE
*/
BOOL oi_symmetry_decrypt2(const BYTE* pInBuf, int nInBufLen, const BYTE* pKey, BYTE* pOutBuf, int *pOutBufLen);


//////////////////////////////////////////////////////////////////////////

#if 0
/// QQ对称计算加密长度第三代函数. (TEA加密算法,CBC模式). 密文格式:PadLen(1byte)+Padding(var,0-7byte)+Salt(2byte)+Body(var byte)+Zero(7byte)
/** @param nInBufLen in,	nInBufLen为需加密的明文部分(Body)长度
@return int,			返回为加密后的长度(是8byte的倍数)
*/
int qq_symmetry_encrypt3_len(int nInBufLen);

/*pKey为16byte*/
/*
	输入:pInBuf为需加密的明文部分(Body),nInBufLen为pInBuf长度;
	输出:pOutBuf为密文格式,pOutBufLen为pOutBuf的长度是8byte的倍数,至少应预留nInBufLen+17;
*/
/*TEA加密算法,CBC模式*/
/*密文格式:PadLen(1byte)+Padding(var,0-7byte)+Salt(2byte)+Body(var byte)+Zero(7byte)*/
//void qq_symmetry_encrypt3(const BYTE* pInBuf, int nInBufLen, DWORD dwUin, const BYTE* pKey, BYTE* pOutBuf, int *pOutBufLen);
//inline void qq_symmetry_encrypt3(const BYTE* pInBuf, int nInBufLen, DWORD dwUin, const BYTE* pKey, BYTE* pOutBuf, int *pOutBufLen);



/*pKey为16byte*/
/*
	输入:pInBuf为密文格式,nInBufLen为pInBuf的长度是8byte的倍数; *pOutBufLen为接收缓冲区的长度
		特别注意*pOutBufLen应预置接收缓冲区的长度!
	输出:pOutBuf为明文(Body),pOutBufLen为pOutBuf的长度,至少应预留nInBufLen-10;
	返回值:如果格式正确返回TRUE;
*/
/*TEA解密算法,CBC模式*/
/*密文格式:PadLen(1byte)+Padding(var,0-7byte)+Salt(2byte)+Body(var byte)+Zero(7byte)*/
//inline BOOL qq_symmetry_decrypt3(const BYTE* pInBuf, int nInBufLen, BYTE chMainVer, BYTE chSubVer, DWORD dwUin, const BYTE* pKey, BYTE* pOutBuf, int *pOutBufLen);
#endif	// 0


/// 4 bytes单位加密的tea
/** @param v in,			data 4 bytes
	@param k in,			key 8 bytes
*/
void _4bytesEncryptAFrame(short *v, short *k);

/// 4 bytes单位解密的tea
/** @param v in,			data 4 bytes
	@param k in,			key 8 bytes
*/
void _4bytesDecryptAFrame(short *v, short *k);


/// 可追加的CRC32校验，crc-->原有的crc校验值，buf-->待追加校验的缓冲，len-->缓冲长度
DWORD CRC32(DWORD crc, const unsigned char* buf, int len);

/**
@}
*/