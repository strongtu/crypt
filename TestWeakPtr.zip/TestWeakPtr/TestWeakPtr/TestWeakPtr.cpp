// TestWeakPtr.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "TestWeakPtr.h"
#include "weak_ptr.h"
#include "ecc/ecdsa.h"
#define MAX_LOADSTRING 100

// Global Variables:
HINSTANCE hInst;								// current instance
TCHAR szTitle[MAX_LOADSTRING];					// The title bar text
TCHAR szWindowClass[MAX_LOADSTRING];			// the main window class name
DWORD g_showdata = 0;
HWND  g_hwnd = NULL;
class TestWeak:public AsyncTask::SupportsWeakPtr<TestWeak>
{
public:
	TestWeak()
	{
		int a = 0;
	}
	~TestWeak()
	{
		int b = 0;
	}
};
#pragma comment(lib,"Ws2_32.lib")
struct ThreadData
{
	int time;
	int mode;
	int threadcount;
};
DWORD WINAPI CalcPrivateThread(void* lParam)
{
	ThreadData *pdata = (ThreadData *)lParam;
	CEcdsa *pecds1 = new CEcdsa;
	//CPublicKey pubKey1;CPrivateKey priKey1;
	//ecds1.GenKey(pubKey1,priKey1);

	const BYTE c_public_key[] = {0x00, 0x00, 0x00, 0x01, 0xB1, 0x0A,
		0xC3, 0xCC, 0x4D, 0xF9, 0x48, 0x80, 0x2F, 0xDA, 0x0A, 0x64, 
		0x57, 0x3E, 0x89, 0x44, 0xF0, 0x39, 0xE0, 0xB2};
		

	//const BYTE c_public_key[] = {0x00,0x00,0x00,0x01,0x6a,0x46,0x18,0xf7,0x42,0xcc,0x85,0x67,0x90,0xc1,0x69,0x0c,0xf0,0xc4,0x88,0xb0,0x3a,0x64,0xaa,0xb9};

	CPublicKey *ppub = new CPublicKey;
	//CSignature sig;
	
	ppub->LoadFromBuf((void*)c_public_key, 
		sizeof(c_public_key) / sizeof(c_public_key[0]));
	//sig.LoadFromBuf((void*)cVerifyCode, c_verify_len);
	DWORD dwTemp = 0;
	for(unsigned int i = pdata->time-pdata->mode /*0x548f90dc*/;i> (0x548f90dc+pdata->threadcount) ;i=i-pdata->threadcount)
	{
		CEcdsa *pecds = new CEcdsa(eccparam::ECC_P160,i);
		CPublicKey *ppubKey = new CPublicKey;CPrivateKey *ppriKey = new CPrivateKey;
		pecds->GenKey(*ppubKey,*ppriKey);	
		if(g_showdata && dwTemp != g_showdata && g_hwnd)
		{
			dwTemp = g_showdata;
			::PostMessage(g_hwnd,WM_USER+100,pdata->mode,i);
		}
		if(ppubKey->v == ppub->v)
		{
			CString str;
			str.Format(_T("private is get,i is :0x%x"),i);
			::MessageBox(NULL,str,_T("temp"),MB_OK);
		}
		delete ppubKey;
		delete ppriKey;
		delete pecds;
	}	
	return 1;
}
#define THREAD_COUNT  7
void testecc()
{
	CEcdsa ecdstemp(eccparam::ECC_P160,1000);
	CPublicKey pubtemp;CPrivateKey privtemp;
	ecdstemp.GenKey(pubtemp,privtemp);
	BYTE pubsave[100] = {0};
	int lentemp = pubtemp.SaveToBuf((void*)pubsave,100);
	
	for(int nthread = 0;nthread <THREAD_COUNT;nthread ++)
	{
		ThreadData *pData = new ThreadData;
		pData->time = 0xFFFFFFFF;
		pData->threadcount = THREAD_COUNT;
		pData->mode = nthread;
		CreateThread(NULL, 0, CalcPrivateThread, (LPVOID)pData, 0, NULL);
	}
	return;
	CEcdsa ecds;
	CPublicKey pubKey;CPrivateKey priKey;
	ecds.GenKey(pubKey,priKey);

	const BYTE c_public_key[] = {0x00, 0x00, 0x00, 0x01, 0xB1, 0x0A,
		0xC3, 0xCC, 0x4D, 0xF9, 0x48, 0x80, 0x2F, 0xDA, 0x0A, 0x64, 
		0x57, 0x3E, 0x89, 0x44, 0xF0, 0x39, 0xE0, 0xB2};

	CPublicKey pub;
	//CSignature sig;

	pub.LoadFromBuf((void*)c_public_key, 
		sizeof(c_public_key) / sizeof(c_public_key[0]));
	//sig.LoadFromBuf((void*)cVerifyCode, c_verify_len);

	for(unsigned int i = 10000 /*0x535c3131*/;i> 0 ;i--)
	{
		CEcdsa ecds(eccparam::ECC_P160,i);
		CPublicKey pubKey;CPrivateKey priKey;
		ecds.GenKey(pubKey,priKey);
		if(pubKey.v == pub.v)
		{
			::MessageBoxA(NULL,"temp","temp",MB_OK);
		}
	}	

// 	CEcdsa ecds;
// 	CPublicKey pubKey;CPrivateKey priKey;
// 	ecds.GenKey(pubKey,priKey);
	CEcdsa ecds2;
	CPublicKey pubKey2;CPrivateKey priKey2;
	ecds2.GenKey(pubKey2,priKey2);
	if(priKey2.v == priKey.v)
	{
		int a =0;
	}
	char bufferkey[42] = {0};
	int keylen = priKey.SaveToBuf(&bufferkey[0],42);
	char buffer[16] = {0};
	CSignature sign;
	char signbuf[48];
	srand(GetTickCount());
	//for(DWORD i = 0;i<0xFFFFFFFF;i++ )
	{
		
		*(int *)&buffer[0] = rand();
		*(int *)&buffer[2] = rand();
		*(int *)&buffer[4] = rand();
		*(int *)&buffer[6] = rand();
		*(int *)&buffer[8] = rand();
		*(int *)&buffer[10] = rand();
		*(int *)&buffer[12] = rand();
		*(int *)&buffer[14] = rand();
		ecds.QQSign(priKey,(const unsigned char *)&buffer[0],sizeof(buffer),sign);
		if(!ecds.QQVerify(pubKey,(const unsigned char *)&buffer[0],sizeof(buffer),sign))
		{
			::MessageBoxA(NULL,"temp","temp",MB_OK);
			
		}
		
	}
	int nlen = sign.SaveToBuf(&signbuf,sign.Len());
	memset((void *)&signbuf[2],0,sizeof(signbuf)-2);
	sign.LoadFromBuf(signbuf,nlen);
	bool isOk = ecds.QQVerify(pubKey,(const unsigned char *)&buffer[0],sizeof(buffer),sign);


	Big big(0);
	Big big3 = 0/big;
	if(big == 0 )
	{
		int c = 0;
	}
	Big big2(0x2323);
	big = big+big2;

	char temp[10]= {0};
	to_binary(big,10,&temp[0]);
	int abc = htonl (*(int *)&temp[0]);
	//::MessageBoxA(NULL,temp,temp,MB_OK);
	if(isOk)
	{
		int a  =0;
	}
	else
	{
		int b = 0;
	}


}
// Forward declarations of functions included in this code module:
ATOM				MyRegisterClass(HINSTANCE hInstance);
BOOL				InitInstance(HINSTANCE, int);
LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK	About(HWND, UINT, WPARAM, LPARAM);
// void uv_fatal_error(const int errorno, const char* syscall) {
// 	char* buf = NULL;
// 	const char* errmsg;
// 
// 	FormatMessageA(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM |
// 		FORMAT_MESSAGE_IGNORE_INSERTS, NULL, errorno,
// 		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), (LPSTR)&buf, 0, NULL);
// 
// 	if (buf) {
// 		errmsg = buf;
// 	} else {
// 		errmsg = "Unknown error";
// 	}
// 
// 	/* FormatMessage messages include a newline character already, */
// 	/* so don't add another. */
// 	if (syscall) {
// 		fprintf(stderr, "%s: (%d) %s", syscall, errorno, errmsg);
// 	} else {
// 		fprintf(stderr, "(%d) %s", errorno, errmsg);
// 	}
// 
// 	if (buf) {
// 		LocalFree(buf);
// 	}
// 
// 	//misoraliu: do not abort.
// 	//*((char*)NULL) = 0xff; /* Force debug break */
// 	//abort();
// }
int APIENTRY _tWinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPTSTR    lpCmdLine,
                     int       nCmdShow)
{
	UNREFERENCED_PARAMETER(hPrevInstance);
	UNREFERENCED_PARAMETER(lpCmdLine);

 	// TODO: Place code here.
	MSG msg;
	msg.hwnd = (HWND)0x1234;
	
	testecc();
	//uv_fatal_error(1,"socket");
	HACCEL hAccelTable;
	TestWeak *p = new TestWeak;
	AsyncTask::WeakPtr<TestWeak> weak = p->AsWeakPtr();
	if(weak.get())
	{
		int c = 0;
	}
	delete p;
	if(weak.get())
	{
		int d = 0;
	}

	// Initialize global strings
	LoadString(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
	LoadString(hInstance, IDC_TESTWEAKPTR, szWindowClass, MAX_LOADSTRING);
	MyRegisterClass(hInstance);

	// Perform application initialization:
	if (!InitInstance (hInstance, nCmdShow))
	{
		return FALSE;
	}

	hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_TESTWEAKPTR));

	// Main message loop:
	while (GetMessage(&msg, NULL, 0, 0))
	{
		if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}

	return (int) msg.wParam;
}



//
//  FUNCTION: MyRegisterClass()
//
//  PURPOSE: Registers the window class.
//
//  COMMENTS:
//
//    This function and its usage are only necessary if you want this code
//    to be compatible with Win32 systems prior to the 'RegisterClassEx'
//    function that was added to Windows 95. It is important to call this function
//    so that the application will get 'well formed' small icons associated
//    with it.
//
ATOM MyRegisterClass(HINSTANCE hInstance)
{
	WNDCLASSEX wcex;

	wcex.cbSize = sizeof(WNDCLASSEX);

	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= WndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInstance;
	wcex.hIcon			= LoadIcon(hInstance, MAKEINTRESOURCE(IDI_TESTWEAKPTR));
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= (HBRUSH)(COLOR_WINDOW+1);
	wcex.lpszMenuName	= MAKEINTRESOURCE(IDC_TESTWEAKPTR);
	wcex.lpszClassName	= szWindowClass;
	wcex.hIconSm		= LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_SMALL));

	return RegisterClassEx(&wcex);
}

//
//   FUNCTION: InitInstance(HINSTANCE, int)
//
//   PURPOSE: Saves instance handle and creates main window
//
//   COMMENTS:
//
//        In this function, we save the instance handle in a global variable and
//        create and display the main program window.
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
   HWND hWnd;

   hInst = hInstance; // Store instance handle in our global variable

   hWnd = CreateWindow(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,
      CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, NULL, NULL, hInstance, NULL);

   if (!hWnd)
   {
      return FALSE;
   }
   g_hwnd = hWnd;

   ShowWindow(hWnd, nCmdShow);
   UpdateWindow(hWnd);

   return TRUE;
}

//
//  FUNCTION: WndProc(HWND, UINT, WPARAM, LPARAM)
//
//  PURPOSE:  Processes messages for the main window.
//
//  WM_COMMAND	- process the application menu
//  WM_PAINT	- Paint the main window
//  WM_DESTROY	- post a quit message and return
//
//
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	int wmId, wmEvent;
	PAINTSTRUCT ps;
	HDC hdc;
	CString str;	
	switch (message)
	{
	case WM_COMMAND:
		wmId    = LOWORD(wParam);
		wmEvent = HIWORD(wParam);
		// Parse the menu selections:
		switch (wmId)
		{
		case IDM_ABOUT:
			//DialogBox(hInst, MAKEINTRESOURCE(IDD_ABOUTBOX), hWnd, About);
			g_showdata = GetTickCount();
			break;
		case IDM_EXIT:
			DestroyWindow(hWnd);
			break;
		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
		}
		break;
	case WM_PAINT:
		hdc = BeginPaint(hWnd, &ps);
		// TODO: Add any drawing code here...
		EndPaint(hWnd, &ps);
		break;
	case WM_DESTROY:
		PostQuitMessage(0);
		break;
	case WM_USER+100:
		str.Format(_T("Thread ID is:%d and time is:%x"),wParam,lParam);
		::MessageBox(g_hwnd,str,_T("test"),MB_OK);
		break;
	default:
		return DefWindowProc(hWnd, message, wParam, lParam);
	}
	return 0;
}

// Message handler for about box.
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		return (INT_PTR)TRUE;

	case WM_COMMAND:
		if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
		{
			EndDialog(hDlg, LOWORD(wParam));
			return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}
